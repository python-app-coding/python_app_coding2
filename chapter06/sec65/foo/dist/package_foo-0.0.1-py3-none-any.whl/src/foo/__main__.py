# coding = utf8

import os


def hello():
    print("demo in  __main__!")


if __name__ == '__main__':
    hello()
