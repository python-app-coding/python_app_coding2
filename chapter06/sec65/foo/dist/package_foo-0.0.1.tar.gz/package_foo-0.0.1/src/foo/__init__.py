# coding = utf8

def hello():
    print("demo in  __init__!")
