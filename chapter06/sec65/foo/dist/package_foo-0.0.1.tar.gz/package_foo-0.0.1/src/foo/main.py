# coding = utf8


def hello():
    print("hello in main.py")


if __name__ == '__main__':
    hello()
