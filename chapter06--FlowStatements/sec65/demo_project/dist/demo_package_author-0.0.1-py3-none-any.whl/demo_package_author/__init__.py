# coding = utf8

def hello():
    """
    演示函数，位于foo包的__init__模块内
    demo function in demo_project.__init__

    >>> hello()
    demo in  __init__!
    """
    print("demo in  __init__!")
